import React, { Component } from "react";

class Spinner extends Component {
  state = {};
  render() {
    return <i className="fa fa-refresh fa-spin"></i>;
  }
}

export default Spinner;
