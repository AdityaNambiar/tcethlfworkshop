# workshopnet

Generating Business network for workshop demo application
